import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import joblib

def LD_DATA(fp):
    # LOAD THE DATASET
    dt = pd.read_csv(fp)
    return dt

def PREPROC_DATA(dt):
    # SEPARATE FEATURES AND TARGET VARIABLE
    X = dt.drop('Class', axis=1)
    y = dt['Class']

    # SPLIT THE DATASET INTO TRAINING AND TESTING SETS
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # STANDARDIZE THE FEATURES
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    return X_train, X_test, y_train, y_test

def TRAIN_SAVE_MOD(X_train, y_train, mod_file, kern_type):
    # CREATE SVM MODEL WITH THE SPECIFIED KERNEL
    mod = SVC(kernel=kern_type)

    # TRAIN THE MODEL
    mod.fit(X_train, y_train)

    # SAVE THE TRAINED MODEL TO A FILE
    joblib.dump(mod, mod_file)
    print(f"Model with {kern_type} kernel saved to {mod_file}")

if __name__ == "__main__":
    fp = 'creditcard.csv'

    kern_types = ['linear', 'poly', 'rbf']  
    for kern_type in kern_types:
        mod_file = f'SVM_{kern_type}.joblib'
        
        data = LD_DATA(fp)
        X_train, X_test, y_train, y_test = PREPROC_DATA(data)
        TRAIN_SAVE_MOD(X_train, y_train, mod_file, kern_type)
