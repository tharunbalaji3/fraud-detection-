import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix, classification_report
import itertools
import matplotlib.pyplot as plt
import joblib

# LOAD THE TRAINED MODELS
CLASSIFIER_LINEAR = joblib.load('Balanced_LinearSVM.joblib')
CLASSIFIER_POLY = joblib.load('Balanced_PolySVM.joblib')
CLASSIFIER_RBF = joblib.load('Balanced_RbfSVM.joblib')

# LOAD THE TEST DATASET
D_TEST = pd.read_csv("creditcard.csv")
DF_TEST = pd.DataFrame(D_TEST)

# EXTRACT FEATURES AND TARGET
X_TEST_ALL = DF_TEST[150000:].drop(['Time', 'Class'], axis=1).to_numpy()
Y_TEST_ALL = DF_TEST[150000:]['Class'].to_numpy()

CLASS_NAMES = np.array(['0', '1'])  # BINARY LABEL

# FUNCTION TO PLOT CONFUSION MATRIX
def plot_confusion_matrix(cm, classes,
                          title,
                          cmap=plt.cm.Blues):
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = 'd'
    thresh = cm.max()/2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')

# MAKE PREDICTIONS AND EVALUATE THE MODELS
PR_LINEAR = CLASSIFIER_LINEAR.predict(X_TEST_ALL)
CM_LINEAR = confusion_matrix(Y_TEST_ALL, PR_LINEAR)

PR_POLY = CLASSIFIER_POLY.predict(X_TEST_ALL)
CM_POLY = confusion_matrix(Y_TEST_ALL, PR_POLY)

PR_RBF = CLASSIFIER_RBF.predict(X_TEST_ALL)
CM_RBF = confusion_matrix(Y_TEST_ALL, PR_RBF)

# PLOT CONFUSION MATRICES AND DISPLAY RESULTS

print("Linear Kernel")
plot_confusion_matrix(CM_LINEAR, CLASS_NAMES,title="Confusion Matrix (Linear Kernel)")
CLASS_REP_LINEAR = classification_report(Y_TEST_ALL, PR_LINEAR)
print(CLASS_REP_LINEAR)
print('We have detected {} frauds / {} total frauds.'.format(CM_LINEAR[1][1], CM_LINEAR[1][1] + CM_LINEAR[1][0]))
print('Probability to detect a fraud is {}'.format(CM_LINEAR[1][1] / (CM_LINEAR[1][1] + CM_LINEAR[1][0])))
print("The accuracy is: {} ".format((CM_LINEAR[0][0] + CM_LINEAR[1][1]) / (sum(CM_LINEAR[0]) + sum(CM_LINEAR[1]))))
plt.show()

print("Polynomial Kernel")
plot_confusion_matrix(CM_POLY, CLASS_NAMES,title="Confusion Matrix (Polynomial Kernel)")
CLASS_REP_POLY = classification_report(Y_TEST_ALL, PR_POLY)
print(CLASS_REP_POLY)
print('We have detected {} frauds / {} total frauds.'.format(CM_POLY[1][1], CM_POLY[1][1] + CM_POLY[1][0]))
print('Probability to detect a fraud is {}'.format(CM_POLY[1][1] / (CM_POLY[1][1] + CM_POLY[1][0])))
print("The accuracy is: {} ".format((CM_POLY[0][0] + CM_POLY[1][1]) / (sum(CM_POLY[0]) + sum(CM_POLY[1]))))
plt.show()

print("RBF Kernel")
plot_confusion_matrix(CM_RBF, CLASS_NAMES,title="Confusion Matrix (RBF Kernel)")
CLASS_REP_RBF = classification_report(Y_TEST_ALL, PR_RBF)
print(CLASS_REP_RBF)
print('We have detected {} frauds / {} total frauds.'.format(CM_RBF[1][1], CM_RBF[1][1] + CM_RBF[1][0]))
print('Probability to detect a fraud is {}'.format(CM_RBF[1][1] / (CM_RBF[1][1] + CM_RBF[1][0])))
print("The accuracy is: {} ".format((CM_RBF[0][0] + CM_RBF[1][1]) / (sum(CM_RBF[0]) + sum(CM_RBF[1]))))
plt.show()
