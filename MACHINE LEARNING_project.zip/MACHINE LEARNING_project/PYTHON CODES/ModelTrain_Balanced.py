import pandas as pd
import numpy as np
from sklearn import svm
import joblib

# LOAD THE DATASET
D = pd.read_csv("creditcard.csv")
DF = pd.DataFrame(D)

# DIVIDE THE DATASET
DF_TRAIN_ALL = DF[0:150000]
DF_TRAIN_1 = DF_TRAIN_ALL[DF_TRAIN_ALL['Class'] == 1]  # FRAUD
DF_TRAIN_0 = DF_TRAIN_ALL[DF_TRAIN_ALL['Class'] == 0]  # NON  FRAUD

print('In this dataset, we have {} frauds so we need to take a similar number of non-fraud'.format(len(DF_TRAIN_1)))

# BALANCE THE DATASET
DF_SAMPLE = DF_TRAIN_0.sample(300)  # No Fraud
DF_TRAIN_BALANCED = pd.concat([DF_TRAIN_1, DF_SAMPLE])  
DF_TRAIN_BALANCED = DF_TRAIN_BALANCED.sample(frac=1) 

# EXTRACT FEATURES AND TARGET
X_TRAIN = DF_TRAIN_BALANCED.drop(['Time', 'Class'], axis=1)  
Y_TRAIN = DF_TRAIN_BALANCED['Class']  
X_TRAIN = np.asarray(X_TRAIN)
Y_TRAIN = np.asarray(Y_TRAIN)

# TRAIN CLASSIFIERS
CLASSIFIER_LINEAR = svm.SVC(kernel='linear', class_weight={0: 0.60, 1: 0.40})
CLASSIFIER_LINEAR.fit(X_TRAIN, Y_TRAIN)

CLASSIFIER_POLY = svm.SVC(kernel='poly', class_weight={0: 0.60, 1: 0.40})
CLASSIFIER_POLY.fit(X_TRAIN, Y_TRAIN)

CLASSIFIER_RBF = svm.SVC(kernel='rbf', class_weight={0: 0.60, 1: 0.40})
CLASSIFIER_RBF.fit(X_TRAIN, Y_TRAIN)

# SAVE MODELS
joblib.dump(CLASSIFIER_LINEAR, 'Balanced_LinearSVM.joblib')
joblib.dump(CLASSIFIER_POLY, 'Balanced_PolySVM.joblib')
joblib.dump(CLASSIFIER_RBF, 'Balanced_RbfSVM.joblib')
