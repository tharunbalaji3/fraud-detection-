import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def LD_DT(fp):
    # LOAD THE DATASET
    dt = pd.read_csv(fp)
    return dt

def EXPLORE_DT(dt):
    # DISPLAY BASIC INFO ABOUT THE DATASET
    print(dt.info())

    # DISPLAY SUMMARY STATISTICS
    print(dt.describe())

def VIZ_DT(dt):

    # VISUALIZE THE DISTRIBUTION OF THE TARGET VARIABLE 'Class'
    plt.figure(figsize=(6, 4))
    sns.countplot(x='Class', data=dt)
    plt.title('Distribution of Classes')
    plt.show()

    # VISUALIZE CORRELATIONS USING A HEATMAP
    plt.figure(figsize=(12, 8))
    corr_matrix = dt.corr()
    sns.heatmap(corr_matrix, cmap='coolwarm', annot=False)
    plt.title('Correlation Matrix')
    plt.show()

    # SCATTER PLOT OF FRAUD AMOUNTS OVER TIME
    plt.figure(figsize=(15, 5))
    df_fraud = dt[dt['Class'] == 1]
    plt.scatter(df_fraud['Time'], df_fraud['Amount'])
    plt.title('Scatter Plot of Fraud Amounts Over Time')
    plt.xlabel('Time')
    plt.ylabel('Amount')
    plt.xlim([0, 175000])
    plt.ylim([0, 2500])
    plt.show()

if __name__ == "__main__":
    FP = 'creditcard.csv'
    DATA = LD_DT(FP)
    EXPLORE_DT(DATA)
    VIZ_DT(DATA)
    NF=len(DATA[DATA.Class == 1])
    NNF=len(DATA[DATA.Class == 0])
    print("Number of Frauds: ",NF)
    print("Number of Non-Frauds: ",NNF)
