import pandas as pd
import joblib
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

def LOAD_DATA(fp):
    # LOAD THE DATASET
    DT = pd.read_csv(fp)
    return DT

def PREPROCESS_DATA(DT):
    # SEPARATE FEATURES AND TARGET VARIABLE
    X = DT.drop('Class', axis=1)
    y = DT['Class']
    return X, y

def LOAD_MODEL(MOD_FILE):
    # LOAD THE TRAINED MODEL FROM A FILE
    MOD = joblib.load(MOD_FILE)
    return MOD

def PLOT_CM(CM, CLASSES, TITLE='Confusion Matrix'):
    sns.heatmap(CM, annot=True, fmt='d', cmap='Blues', xticklabels=CLASSES, yticklabels=CLASSES)
    plt.title(TITLE)
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.show()

def TEST_MOD(X_TEST, Y_TEST, MOD, KERN_TYPE):
    # MAKE PREDICTIONS ON THE TEST SET
    Y_PRED = MOD.predict(X_TEST)

    # EVALUATE THE MODEL
    ACC = accuracy_score(Y_TEST, Y_PRED)
    CM = confusion_matrix(Y_TEST, Y_PRED)
    CLASS_REP = classification_report(Y_TEST, Y_PRED)

    # PLOT CONFUSION MATRIX
    PLOT_CM(CM, ['Non-Fraud', 'Fraud'], TITLE=f'Confusion Matrix ({KERN_TYPE} Kernel)')

    # DISPLAY RESULTS
    print(f"Results for SVM with {KERN_TYPE} kernel:")
    print(f"Accuracy: {ACC:.4f}")
    print("Confusion Matrix:")
    print(CM)
    print("Classification Report:")
    print(CLASS_REP)
    print(f"We have detected {CM[1][1]} frauds / {CM[1][1] + CM[1][0]} total frauds.")
    print(f"Probability to detect a fraud is {CM[1][1] / (CM[1][1] + CM[1][0])}")
    print("The accuracy is: {} ".format((CM[0][0] + CM[1][1]) / (sum(CM[0]) + sum(CM[1]))))

if __name__ == "__main__":
    FP = 'creditcard.csv'

#FOR UNBALANCED DATASET
    KERN_TYPES = ['linear', 'poly', 'rbf']  
    for KERN_TYPE in KERN_TYPES:
        MOD_FILE_UB = f'SVM_{KERN_TYPE}.joblib'
        DATA = LOAD_DATA(FP)
        X, Y = PREPROCESS_DATA(DATA)
        MODEL = LOAD_MODEL(MOD_FILE_UB)
        TEST_MOD(X, Y, MODEL, KERN_TYPE)

